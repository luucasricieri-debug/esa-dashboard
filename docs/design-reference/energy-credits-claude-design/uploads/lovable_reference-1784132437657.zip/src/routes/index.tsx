import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/esa/Shell";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ESA Energia — Gestão de Créditos" },
      {
        name: "description",
        content:
          "Módulo operacional de gestão de créditos de energia por assinatura da ESA Energia.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return <Shell />;
}
